#ifndef SO_CLIENT_CLIENT_H
#define SO_CLIENT_CLIENT_H

void setupClient();

#endif
