#ifndef SERVER_H
#define SERVER_H

void *clientHandler(void *arg);
void setupServer();

#endif
