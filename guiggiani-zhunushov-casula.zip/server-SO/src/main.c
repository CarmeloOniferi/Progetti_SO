#include "../include/server.h"

int main(void)
{
    setupServer();
    return 0;
}
